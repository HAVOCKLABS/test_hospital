
Simulador SIGR (inserta lecturas cada 20s)
=========================================

### Qué agrega
1. Modelo `Telemetria` en `models.py` (tabla nueva).
2. Blueprint `routes_simulador.py` con endpoints:
   - GET  /api/telemetria/live?limit=N  → lecturas más recientes (JSON)
   - GET  /simulador/mode               → estado actual del simulador
   - POST /simulador/mode               → cambiar modo (`{"mode":"normal"|"falla","falla":"..."}`)
3. Hilo de fondo que inserta una lectura cada 20 segundos (se inicia en `routes.py`).
4. Pantalla `/simulador` (solo admin) para cambiar entre "normal" y "falla".
5. Un script que hace *polling* en `dashboard.html` para actualizar elementos con las clases:
   - `.js-kw`, `.js-fp`, `.js-water`, `.js-oxy-flow`, `.js-oxy-press`, `.js-oxy-level`

> Nota: El script es seguro si los elementos no existen — simplemente no hace nada.

### Cómo aplicar migración
Con entorno del proyecto activado:
```
flask db migrate -m "add Telemetria table"
flask db upgrade
```

### Fallas simuladas incluidas
- `spike_kw`: pico súbito de kW
- `brownout`: bajón de potencia
- `pf_bajo`: factor de potencia bajo (< 0.8)
- `fuga_agua`: flujo alto sostenido
- `sin_flujo_agua`: flujo 0
- `oxigeno_presion_baja`: presión y flujo bajos de oxígeno
- `oxigeno_vaciado_rapido`: nivel desciende rápidamente
- `sensor_atrascado_kw`: valor de kW se repite

### Cómo usar
1. Inicia la app (modo desarrollo): `python app.py`
2. Entra como admin (usuario: admin / pass: admin123 la primera vez)
3. Visita `/simulador` para alternar el modo (normal / falla)
4. En el dashboard, agrega spans con las clases anteriores para ver los indicadores en vivo.
   Ejemplo:
   ```html
   <span class="js-kw"></span> kW — FP: <span class="js-fp"></span>
   ```

