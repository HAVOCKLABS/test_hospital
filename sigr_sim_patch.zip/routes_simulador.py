
# routes_simulador.py
import random, time, threading
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request, current_app
from flask_login import login_required
from sqlalchemy import desc

from models import db, Telemetria

bp_sim = Blueprint("sim", __name__)

# Estado en memoria para el modo del simulador
_SIM_STATE = {"mode": "normal", "falla": None}

# Rangos de referencia (ajústalos a tu realidad)
NORMAL = {
    "electricity_kw":  (10, 30),
    "factor_potencia": (0.92, 0.99),
    "water_lpm":       (80, 160),
    "oxy_flow_lpm":    (50, 70),
    "oxy_pressure_psi":(45, 55),
    "oxy_level_pct":   (60, 100),
}

# Fallas disponibles y su lógica de generación
def gen_fault_sample(falla, prev: dict):
    # Usa el último valor como base para fallas con memoria (p. ej. 'rapid_drain')
    if not prev:
        prev = {}

    if falla == "spike_kw":
        return {
            "electricity_kw": random.uniform(80, 120),
            "factor_potencia": random.uniform(0.85, 0.92),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "brownout":
        return {
            "electricity_kw": random.uniform(0, 5),
            "factor_potencia": random.uniform(0.80, 0.90),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "pf_bajo":
        return {
            "electricity_kw": random.uniform(*NORMAL["electricity_kw"]),
            "factor_potencia": random.uniform(0.65, 0.79),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "fuga_agua":
        # Flujo alto sostenido
        return {
            "electricity_kw": random.uniform(*NORMAL["electricity_kw"]),
            "factor_potencia": random.uniform(*NORMAL["factor_potencia"]),
            "water_lpm": random.uniform(220, 320),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "sin_flujo_agua":
        return {
            "electricity_kw": random.uniform(*NORMAL["electricity_kw"]),
            "factor_potencia": random.uniform(*NORMAL["factor_potencia"]),
            "water_lpm": 0.0,
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "oxigeno_presion_baja":
        return {
            "electricity_kw": random.uniform(*NORMAL["electricity_kw"]),
            "factor_potencia": random.uniform(*NORMAL["factor_potencia"]),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(20, 35),
            "oxy_pressure_psi": random.uniform(20, 35),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    if falla == "oxigeno_vaciado_rapido":
        level = prev.get("oxy_level_pct", random.uniform(60, 80))
        level = max(0.0, level - random.uniform(2.0, 4.0))
        return {
            "electricity_kw": random.uniform(*NORMAL["electricity_kw"]),
            "factor_potencia": random.uniform(*NORMAL["factor_potencia"]),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": level,
        }
    if falla == "sensor_atrascado_kw":
        # Repite exactamente el valor anterior
        return {
            "electricity_kw": prev.get("electricity_kw", random.uniform(*NORMAL["electricity_kw"])),
            "factor_potencia": prev.get("factor_potencia", random.uniform(*NORMAL["factor_potencia"])),
            "water_lpm": random.uniform(*NORMAL["water_lpm"]),
            "oxy_flow_lpm": random.uniform(*NORMAL["oxy_flow_lpm"]),
            "oxy_pressure_psi": random.uniform(*NORMAL["oxy_pressure_psi"]),
            "oxy_level_pct": prev.get("oxy_level_pct", random.uniform(*NORMAL["oxy_level_pct"])),
        }
    # fallback: valores normales
    return gen_normal_sample()

def gen_normal_sample():
    return {
        k: random.uniform(a, b) for k, (a, b) in NORMAL.items()
    }

@bp_sim.get("/api/telemetria/live")
@login_required
def api_live():
    limit = int(request.args.get("limit", 30))
    rows = (Telemetria.query.order_by(desc(Telemetria.ts)).limit(limit).all())
    data = [{
        "ts": r.ts.isoformat(),
        "electricity_kw": r.electricity_kw,
        "factor_potencia": r.factor_potencia,
        "water_lpm": r.water_lpm,
        "oxy_flow_lpm": r.oxy_flow_lpm,
        "oxy_pressure_psi": r.oxy_pressure_psi,
        "oxy_level_pct": r.oxy_level_pct,
        "mode": r.mode,
        "falla": r.falla,
    } for r in rows][::-1]
    return jsonify(data)

@bp_sim.get("/simulador/mode")
@login_required
def get_mode():
    return jsonify(_SIM_STATE)

@bp_sim.post("/simulador/mode")
@login_required
def set_mode():
    body = request.get_json(silent=True) or {}
    mode = body.get("mode", "normal")
    falla = body.get("falla")
    if mode not in ("normal", "falla"):
        return jsonify({"error":"mode debe ser 'normal' o 'falla'"}), 400
    _SIM_STATE["mode"] = mode
    _SIM_STATE["falla"] = falla
    current_app.logger.info(f"[SIM] Cambiado modo a {mode} (falla={falla})")
    return jsonify(_SIM_STATE)

def _simulator_loop(app):
    """Bucle que inserta una lectura cada 20s"""
    prev = {}
    with app.app_context():
        while True:
            if _SIM_STATE["mode"] == "falla":
                sample = gen_fault_sample(_SIM_STATE["falla"], prev)
            else:
                sample = gen_normal_sample()

            # Guarda
            row = Telemetria(
                electricity_kw = sample["electricity_kw"],
                factor_potencia= sample["factor_potencia"],
                water_lpm      = sample["water_lpm"],
                oxy_flow_lpm   = sample["oxy_flow_lpm"],
                oxy_pressure_psi=sample["oxy_pressure_psi"],
                oxy_level_pct  = sample["oxy_level_pct"],
                mode           = _SIM_STATE["mode"],
                falla          = _SIM_STATE["falla"],
            )
            db.session.add(row)
            db.session.commit()

            prev = sample
            time.sleep(20)

def start_simulator(app):
    # Evita múltiples hilos en recargas de debug
    if app.config.get("_SIM_STARTED"):
        return
    app.config["_SIM_STARTED"] = True
    t = threading.Thread(target=_simulator_loop, args=(app,), daemon=True)
    t.start()
